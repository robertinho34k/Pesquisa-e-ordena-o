/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aula;

/**
 *
 * @author laboratorio
 */
public class TesteString {
    public static void main(String[] args) {
        //Algoritmos geneticos
        //cromossomo - estado - objeto -> conjunto de genes
        //pai - "00000000001111111111"
        //mae - "99999999997777777777"
        //filho1 - primeiraParteDoPai + segundaParteDaMae - 00000000007777777777
        //filho2 - primeiraParteDaMae + segundaParteDoPai = 99999999991111111111
        
        String pai = ("12345678");
        String mae = ("ABCDEFGH");
        
        String[] listaCruzas = Metodos.cruzaGenetica(pai,mae);
        
        for(int i = 0; i<2; i++){
            System.out.println(listaCruzas[i]);
        }
        
        
        /*
        String string = new String();
        StringBuffer stringBuffer = new StringBuffer();
        StringBuilder stringBuilder = new StringBuilder();


        string = "turma de pesquisa e ordenacao";
        System.out.println(string.length());
        stringBuffer = new StringBuffer("explicação sobre pesquisa digital");
        stringBuilder = new StringBuilder("texto muito grande");
        
        System.out.println(string.indexOf("ordenacao"));
        System.out.println(stringBuffer.lastIndexOf("ordenacao"));
        */
        
    }
    
}
