/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aula;

/**
 *
 * @author laboratorio
 */
public class Metodos {
    
    public static String[] cruzaGenetica(String pai, String mae){
        
        int tamPai = pai.length();
        int pontoDeCruza = pai.length() / 2;
        
        StringBuffer filho1 = new StringBuffer();
        StringBuffer filho2 = new StringBuffer();
        
        filho1.append(pai.substring(0, pontoDeCruza));
        filho1.append(mae.substring(pontoDeCruza, tamPai));
        
        filho2.append(mae.substring(0, pontoDeCruza));
        filho2.append(pai.substring(pontoDeCruza, tamPai));
        
        String[] stringlistafilhos =  {filho1.toString(),filho2.toString()};
        return stringlistafilhos;
    }
    
}
